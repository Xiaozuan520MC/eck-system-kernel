.uobj/chmod.o: user/chmod.c include/types.h include/stat.h include/user.h
