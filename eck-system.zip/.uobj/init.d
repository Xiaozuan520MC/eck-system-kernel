.uobj/init.o: user/init.c include/types.h include/stat.h include/user.h \
 include/fcntl.h include/fs.h include/file.h
