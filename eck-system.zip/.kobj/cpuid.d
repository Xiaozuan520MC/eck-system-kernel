.kobj/cpuid.o: kernel/cpuid.c include/types.h include/defs.h include/fs.h \
 include/file.h include/cpuid.h
