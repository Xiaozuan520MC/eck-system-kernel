.kobj/lapic.o: kernel/lapic.c include/types.h include/defs.h \
 include/date.h include/memlayout.h include/traps.h include/mmu.h \
 include/x86.h include/param.h include/proc.h
