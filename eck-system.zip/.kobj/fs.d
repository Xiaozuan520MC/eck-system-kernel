.kobj/fs.o: kernel/fs.c include/types.h include/defs.h include/param.h \
 include/stat.h include/mmu.h include/proc.h include/spinlock.h \
 include/fs.h include/buf.h include/file.h
